// Please paste the index.js code from the OTHER working bot here.
// I will analyze it and apply the fixes to your current bot.
