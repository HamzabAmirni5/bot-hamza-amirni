const checkImageCommand = require('./checkimage');
module.exports = checkImageCommand;
