// Alias for banana-ai command
const bananaAiCommand = require('./banana-ai');
module.exports = bananaAiCommand;
