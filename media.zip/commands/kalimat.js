// Alias for lyrics command
const lyricsCommand = require('./lyrics');
module.exports = lyricsCommand;
