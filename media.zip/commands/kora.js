// Alias for football command
const footballCommand = require('./football');

module.exports = footballCommand;
