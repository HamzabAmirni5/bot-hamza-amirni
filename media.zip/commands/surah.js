const quranCommand = require('./quran');
module.exports = quranCommand;
