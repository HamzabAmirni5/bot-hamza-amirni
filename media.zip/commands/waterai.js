const waterbotCommand = require('./waterbot');
module.exports = waterbotCommand;
