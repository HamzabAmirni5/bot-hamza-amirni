// Alias for currency command
const currencyCommand = require('./currency');

module.exports = currencyCommand;
