const veo3PromptCommand = require('./veo3-prompt');
module.exports = veo3PromptCommand;
