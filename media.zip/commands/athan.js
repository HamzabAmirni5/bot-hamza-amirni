// Alias for adhan command
const adhanCommand = require('./adhan');
module.exports = adhanCommand;
