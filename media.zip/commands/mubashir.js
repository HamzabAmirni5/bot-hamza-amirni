// Alias for live command
const liveCommand = require('./live');
module.exports = liveCommand;
