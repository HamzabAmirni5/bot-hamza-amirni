// Alias for weather command
const weatherCommand = require('./weather');
module.exports = weatherCommand;
