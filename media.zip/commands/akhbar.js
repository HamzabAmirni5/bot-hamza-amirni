// Alias for news command
const newsCommand = require('./news');
module.exports = newsCommand;
