// Alias for the original book search command
const bookCommand = require('./book');
module.exports = bookCommand;
