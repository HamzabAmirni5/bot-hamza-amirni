// Alias for apk2 command
const apk2Command = require('./apk2');
module.exports = apk2Command;
