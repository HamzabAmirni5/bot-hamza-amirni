const fetch = require('node-fetch');

const questions = [
    "شنو هي أكبر كذبة قولتيها لوالديك؟",
    "شكون هو الشخص اللي ندمتي حيت عرفتيه؟",
    "شنو هي الحاجة اللي درتيها وندمتي عليها بزاف؟",
    "واش عمرك سرقتي شي حاجة؟ وشنو هي؟",
    "واش عمرك بكيتي بسباب شي فيلم؟ وشنو هو؟",
    "شنو هو السر اللي مخبي على صحابك كاملين؟",
    "واش عمرك تجسستي على تيليفون ديال شي واحد؟",
    "إلا كان عندك فرصة ترجع بالزمن، شنو هي اللحظة اللي غاتغير؟",
    "شكون هو الشخص اللي كترتاح ليه كثر من راسك؟",
    "شنو هي أسوأ هدية وصلاتك وعجبتكش ولكن درتي راسك فرحان؟",
    "واش عمرك ضربتي شي حد وتخبيتي؟",
    "شنو هي العادة الخايبة اللي فيك وبغيتي تحيدها؟",
    "واش كظن بلي نتا شخص مزيان؟ وعلاش؟",
    "شنو هو الحلم اللي مستحيل تتخلى عليه؟",
    "واش عمرك شكيتي فشي واحد قريب ليك؟",
    "شنو هي الكلمة اللي قاليها ليك شي حد وعمرك نسيتيها؟"
];

async function truthCommand(sock, chatId, msg) {
    try {
        const randomQuestion = questions[Math.floor(Math.random() * questions.length)];

        await sock.sendMessage(chatId, {
            text: `🤥 *صراحة* 🤥\n\n${randomQuestion}`,
            footer: 'Hamza Amirni 🤖'
        }, { quoted: msg });
    } catch (error) {
        console.error('Error in truth command:', error);
        await sock.sendMessage(chatId, { text: '❌ وقع شي خطأ.' }, { quoted: msg });
    }
}

module.exports = truthCommand;
