const vocalRemoverCommand = require('./vocalremover');
module.exports = vocalRemoverCommand;
