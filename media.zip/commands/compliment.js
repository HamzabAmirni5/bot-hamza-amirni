const compliments = [
    "نت(ي) ناضي(ة) بزاف كما نتا/نتي!",
    "عندك واحد الضحكة كتهبببل!",
    "تبارك الله عليك، القلب الكبير والسخاء.",
    "نتا/نتي أقوى مما كتخايل(ي).",
    "فينما مشيتي كتضوي البلاصة!",
    "نتا/نتي هو الصديق(ة) لي كيحلم بيه أي واحد.",
    "كتعطيني بزاف ديال الطاقة الإيجابية!",
    "الإبداع ديالك ما عندوش حدود!",
    "عندك قلب مذهب، تبارك الله.",
    "وجودك كيدير فرق كبير فالعالم.",
    "الروح ديالك ديما زوينة!",
    "عندك واحد الصبر تبارك الله عليك.",
    "كتخرج أحسن ما عند الناس لي دايرين بيك.",
    "الابتسامة ديالك كتفرح كاع الناس.",
    "تبارك الله عليك فكلشي كديرو، فنان(ة).",
    "الطيبوبة ديالك كترد هاد العالم مكان أحسن.",
    "عندك نظرة زوينة وخاصة للحياة.",
    "الحماس ديالك كيعادي بالزاف، ناضي(ة)!",
    "تبارك الله عليك، كدخل الخاطر بلا استئذان! ❤️",
    "الزين والهمة، الله يحفظك من العين.",
    "كلامك ديما موزون وحلو بحال العسل 🍯",
    "نتا/نتي عملة نادرة فهاد الزمان 💎",
    "القلب الأبيض والنية الصافية، هادشي لي كيميزك ✨",
    "تبارك الله، حضورك كيعطي هيبة للمكان.",
    "نتا/نتي بحال شي نسمة باردة فنهار صهود 🌬️",
    "الله يعطيك على قد نيتك زوينة 🤲",
    "فينما كنتي كيكون الخير والربح.",
    "نتا/نتي مثال للأخلاق والتربية، تبارك الله.",
    "الضحكة ديالك علاج للأعصاب 😂❤️",
    "نتا/نتي ماشي غير صديق، نتا/نتي سند.",
    "عندك واحد الذكاء تبارك الله، كيعجبني تفكيرك 🧠💡",
    "ديما أنيق/أنيقة، الذوق الرفيع! 👔👗",
    "كلشي كيبغيك حيت قلبك طيب.",
    "نتا/نتي منبع ديال الطاقة الإيجابية 🔋⚡",
    "الزين والعقل، جمعتيهم بجوج، تبارك الله.",
    "الله يخلي ليك دوك الوالدين لي رباوك 👪",
    "نتا/نتي كنز ومكيعرف قيمتك غير لي عاشرك.",
    "تبارك الله عليك، قدوة للجميع."
];

async function complimentCommand(sock, chatId, message) {
    try {
        if (!message || !chatId) return;

        let userToCompliment;

        // Check for mentioned users
        if (message.message?.extendedTextMessage?.contextInfo?.mentionedJid?.length > 0) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.mentionedJid[0];
        }
        // Check for replied message
        else if (message.message?.extendedTextMessage?.contextInfo?.participant) {
            userToCompliment = message.message.extendedTextMessage.contextInfo.participant;
        }

        if (!userToCompliment) {
            await sock.sendMessage(chatId, {
                text: '❌ عافاك طاكي خونا ولا رد على ميساجو باش نعطيوه كلمة زينة!'
            }, { quoted: message });
            return;
        }

        const compliment = compliments[Math.floor(Math.random() * compliments.length)];

        await sock.sendMessage(chatId, {
            text: `ياك أ @${userToCompliment.split('@')[0]}؟ \n\n✨ ${compliment}`,
            mentions: [userToCompliment]
        }, { quoted: message });
    } catch (error) {
        console.error('Error in compliment command:', error);
        await sock.sendMessage(chatId, { text: '❌ وقع شي مشكل.' }, { quoted: message });
    }
}

module.exports = complimentCommand;
