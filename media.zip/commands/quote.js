const quotes = [
    { text: "اللي بغا العسل يصبر لقريص النحل.", author: "مثل مغربي" },
    { text: "عش نهار تسمع خبار.", author: "مثل مغربي" },
    { text: "اللي عضو الحنش كيخاف من الحبل.", author: "مثل مغربي" },
    { text: "ما دير خير ما يطرا باس.", author: "مثل مغربي" },
    { text: "اللي فات مات، واللي جاي هو الحياة.", author: "حكمة" },
    { text: "الزين كيحشم على زينو، والخايب غير إلى هداه الله.", author: "مثل مغربي" },
    { text: "اليد الواحدة لا تصفق.", author: "مثل عربي" },
    { text: "اتق شر من أحسنت إليه.", author: "حكمة" },
    { text: "المال يجر المال، والقمل يجر السيبان.", author: "مثل مغربي" },
    { text: "كل تأخيرة فيها خيرة.", author: "مثل عربي" },
    { text: "اللي مربي فالعز، كيبان فوجهو.", author: "مثل مغربي" },
    { text: "اللسان الحلو كيرضع اللبؤة.", author: "مثل مغربي" },
    { text: "لا تكن ليناً فتعصر، ولا صلباً فتكسر.", author: "علي بن أبي طالب" },
    { text: "رضا الناس غاية لا تدرك.", author: "حكمة" },
    { text: "القناعة كنز لا يفنى.", author: "علي بن أبي طالب" },
    { text: "الدنيا دوارة، يوم ليك ويوم عليك.", author: "حكمة" }
];

module.exports = async function quoteCommand(sock, chatId, message) {
    try {
        const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];

        // Make it look cool with emojis
        const quoteMessage = `💡 *حكمة اليوم* 💡\n\n"${randomQuote.text}"\n\n✍️ — *${randomQuote.author}*`;

        await sock.sendMessage(chatId, {
            text: quoteMessage,
            footer: 'Hamza Amirni 🤖'
        }, { quoted: message });
    } catch (error) {
        console.error('Error in quote command:', error);
        await sock.sendMessage(chatId, { text: '❌ وقع شي خطأ فالحكمة.' }, { quoted: message });
    }
};
