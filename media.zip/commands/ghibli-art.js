const ghibliCommand = require('./ghibli');
module.exports = ghibliCommand;
