// Alias for car command
const carCommand = require('./car');
module.exports = carCommand;
