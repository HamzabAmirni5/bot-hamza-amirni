// Alias for recipe command
const recipeCommand = require('./recipe');
module.exports = recipeCommand;
