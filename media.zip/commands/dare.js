const fetch = require('node-fetch');

const dares = [
    "صيفط ميساج لـ 'باك' وقول ليه راني كنتكيف دبا.",
    "صور راسك ونتا كدير شي وجه مضحك وحطها ستوري.",
    "صوني على آخر نمرة عيطات ليك وغني ليهم 'سنة حلوة يا جميل'.",
    "بدل السمية ديالك فالواتساب لـ 'أنا حمار' لمدة ساعة.",
    "صيفط ميساج لخوك/ختك وقول ليهم: 'أنا متبني'.",
    "تمشّى فالدار بحال السلحفاة لمدة 5 دقايق.",
    "كول معلقة د الحار دقة وحدة.",
    "لبس حوايجك بالمقلوب وتصور بيهم.",
    "صوني على صاحبك وقول ليه: 'راني كنتوحم'.",
    "دير ماكياج (للبنات: ديري شنب) وتصور بيه.",
    "عيط لمول الحانوت وسولو واش كيبيع 'الريح فقرعة'.",
    "صيفط لـ 'Crush' ديالك (أو شي حد عزيز عليك): 'كنبغيك' ومسحها دغيا.",
    "غني أغنية فوايام وصيفطها فالكروب.",
    "هضر باللغة العربية الفصحى لمدة 10 دقايق."
];

async function dareCommand(sock, chatId, msg) {
    try {
        const randomDare = dares[Math.floor(Math.random() * dares.length)];

        await sock.sendMessage(chatId, {
            text: `🔥 *تحدي* 🔥\n\n${randomDare}`,
            footer: 'Hamza Amirni 🤖'
        }, { quoted: msg });
    } catch (error) {
        console.error('Error in dare command:', error);
        await sock.sendMessage(chatId, { text: '❌ وقع شي خطأ.' }, { quoted: msg });
    }
}

module.exports = dareCommand;
