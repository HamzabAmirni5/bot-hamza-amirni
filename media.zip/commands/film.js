// Alias for movie command
const movieCommand = require('./movie');
module.exports = movieCommand;
